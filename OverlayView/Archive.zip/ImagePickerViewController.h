//
//  ViewController.h
//  OverlayView
//
//  Created by user on 21/04/15.
//  Copyright (c) 2015 user. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ImagePickerViewController : UIImagePickerController
{

}
@end

